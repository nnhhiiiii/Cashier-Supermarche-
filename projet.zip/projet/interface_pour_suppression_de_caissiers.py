from tkinter import *
import pandas as pd
from tkinter import messagebox
from openpyxl import *


interface_pour_supprimer_un_caissier = Tk()
interface_pour_supprimer_un_caissier.geometry("500x500")
interface_pour_supprimer_un_caissier.title(string = "GesMag")

label_supprimer_caissier = Label(interface_pour_supprimer_un_caissier, text = "Suppression des caissiers", font = ("Arial", 14, "bold"))
label_supprimer_caissier.grid()


label_supprimer_identifiant_caissier = Label(interface_pour_supprimer_un_caissier, text = "Id", font =("Arial", 12))
label_supprimer_identifiant_caissier.grid()
zone_de_saisi_supprimer_identifiant_caissier = Entry(interface_pour_supprimer_un_caissier)
zone_de_saisi_supprimer_identifiant_caissier.grid()

wb = load_workbook('base_de_données_caissiers_et_managers.xlsx')
sheet = wb.active
df = pd.read_excel('base_de_données_caissiers_et_managers.xlsx')

def mess():
    mask = df["Identifiant"].values
    if zone_de_saisi_supprimer_identifiant_caissier.get() in mask:
        messagebox.showinfo(message = "C'est bon")
    else:
        messagebox.showerror(message = "Non id")
        zone_de_saisi_supprimer_identifiant_caissier.delete(0, END)

def remove(sheet, row):
    for cell in row:
        if cell.value != zone_de_saisi_supprimer_identifiant_caissier.get():
            return
            
        else:
            sheet.delete_rows(row[0].row, 1)
        

def supprimer():
    mess()
    for row in sheet:
        remove(sheet, row)
    wb.save('base_de_données_caissiers_et_managers.xlsx')
    zone_de_saisi_supprimer_identifiant_caissier.delete(0, END)

def vider():
    zone_de_saisi_supprimer_identifiant_caissier.delete(0, END)


def quitter():
    interface_pour_supprimer_un_caissier.destroy()


bouton_pour_supprimer = Button(interface_pour_supprimer_un_caissier, text = "Supprimer", width = 10, command = supprimer)
bouton_pour_supprimer.grid()


bouton_pour_quitter = Button(interface_pour_supprimer_un_caissier, text = "Vider", width = 10, command = vider)
bouton_pour_quitter.grid()


bouton_pour_vider = Button(interface_pour_supprimer_un_caissier, text = "Quitter", width = 10, command = quitter)
bouton_pour_vider.grid()

interface_pour_supprimer_un_caissier.mainloop()