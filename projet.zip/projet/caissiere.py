import tkinter
from tkinter import *
from tkinter import ttk
from tkinter.font import BOLD
from PIL import Image, ImageTk


#Création de la fenêtre
fenPrin = Tk()
fenPrin.title(string = "Magasins")
fenPrin.geometry("1100x900")


#Création des images des produits
img1 = Image.open("legumes.jpeg")
resize_img1 = img1.resize((400,250), Image.ANTIALIAS)
new_img1 = ImageTk.PhotoImage(resize_img1)

img2 = Image.open("boulangerie.jpeg")
resize_img2 = img2.resize((400,250), Image.ANTIALIAS)
new_img2 = ImageTk.PhotoImage(resize_img2) 

img3 = Image.open("boucherie.jpeg")
resize_img3 = img3.resize((400,250), Image.ANTIALIAS)
new_img3 = ImageTk.PhotoImage(resize_img3)

img4 = Image.open("produit.jpeg")
resize_img4 = img4.resize((400,250), Image.ANTIALIAS)
new_img4 = ImageTk.PhotoImage(resize_img4)


#Création des fenêtres de chaque rayon
#Fruits et Légumes
def rayon1():
    fen1 = Toplevel()
    fen1.geometry("950x420")
    fen1.title("Fruits et Légumes")

    #Création la fenêtre de l'information 
    def open_mangue():
        mango = Toplevel()
        mango.geometry("900x100")
        mango.title("Mangue")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(mango, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('324268', 'Mangue', '15', '2€59/pièce'))
        tree.pack()
        mango.mainloop()

    p1 = ImageTk.PhotoImage(file = "mangue.png")
    b1 = Button(fen1, image = p1, command = open_mangue)
    b1.grid(row = 1, column = 1)

    #Création la fenêtre de l'information 
    def open_kiwi():
        kiwi = Toplevel()
        kiwi.geometry("900x100")
        kiwi.title("Kiwi")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(kiwi, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('683736', 'Kiwi HAYWARD', '12', '0€59/pièce'))
        tree.pack()
        kiwi.mainloop()

    p2 = ImageTk.PhotoImage(file = "kiwi.jpeg")
    b2 = Button(fen1, image = p2, command = open_kiwi)
    b2.grid(row = 1, column = 2)

    #Création la fenêtre de l'information 
    def open_banane():
        banane = Toplevel()
        banane.geometry("900x100")
        banane.title("Banane")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(banane, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('093658', 'Banane CAVENDISH', '18', '0€99/pièce'))
        tree.pack()
        banane.mainloop()

    p3 = ImageTk.PhotoImage(file = "banane.jpeg")
    b3 = Button(fen1, image = p3, command = open_banane)
    b3.grid(row = 1, column = 3)

    #Création la fenêtre de l'information 
    def open_pomme():
        pomme = Toplevel()
        pomme.geometry("900x100")
        pomme.title("Pomme")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(pomme, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('275398', 'Pomme PINKLADY', '24', '0€70/pièce'))
        tree.pack()
        pomme.mainloop()

    p4 = ImageTk.PhotoImage(file = "pomme.jpeg")
    b4 = Button(fen1, image = p4, command = open_pomme)
    b4.grid(row = 1, column = 4)

    #Création la fenêtre de l'information 
    def open_raisin():
        raisin = Toplevel()
        raisin.geometry("900x100")
        raisin.title("Raisin")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(raisin, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('735475', 'Raisin ESPAGNE sans pépin', '10', '2€50/pièce'))
        tree.pack()
        raisin.mainloop()

    p5 = ImageTk.PhotoImage(file = "raisin.jpeg")
    b5 = Button(fen1, image = p5, command = open_raisin)
    b5.grid(row = 1, column = 5)

    #Création la fenêtre de l'information 
    def open_courge():
        courge = Toplevel()
        courge.geometry("900x100")
        courge.title("Courge")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(courge, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('936254', 'Courge Butternut', '14', '0€99/pièce'))
        tree.pack()
        courge.mainloop()

    p6 = ImageTk.PhotoImage(file = "courge.jpeg")
    b6 = Button(fen1, image = p6, command = open_courge)
    b6.grid(row = 2, column = 1)

    #Création la fenêtre de l'information 
    def open_laitue():
        laitue = Toplevel()
        laitue.geometry("900x100")
        laitue.title("Laitue")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(laitue, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('235174', 'Salad Laitue vert', '19', '0€99/pièce'))
        tree.pack()
        laitue.mainloop()

    p7 = ImageTk.PhotoImage(file = "laitue.jpeg")
    b7 = Button(fen1, image = p7, command = open_laitue)
    b7.grid(row = 2, column = 2)

    #Création la fenêtre de l'information 
    def open_carotte():
        carotte = Toplevel()
        carotte.geometry("900x100")
        carotte.title("Carotte")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(carotte, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('174625', 'Carotte Rhône-Alpes', '24', '0€80/pièce'))
        tree.pack()
        carotte.mainloop()

    p8 = ImageTk.PhotoImage(file = "carotte.jpeg")
    b8 = Button(fen1, image = p8, command = open_carotte)
    b8.grid(row = 2, column = 3)

    #Création la fenêtre de l'information 
    def open_choux():
        choux = Toplevel()
        choux.geometry("900x100")
        choux.title("Choux")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(choux, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('562841', 'Choux fleur', '13', '1€19/pièce'))
        tree.pack()
        choux.mainloop()

    p9 = ImageTk.PhotoImage(file = "choux.jpeg")
    b9 = Button(fen1, image = p9, command = open_choux)
    b9.grid(row = 2, column = 4)

    #Création la fenêtre de l'information 
    def open_brocoli():
        brocoli = Toplevel()
        brocoli.geometry("900x100")
        brocoli.title("Brocoli")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(brocoli, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('801830', 'Chou Brocoli BRETAGNE', '16', '1€70/pièce'))
        tree.pack()
        brocoli.mainloop()

    p10 = ImageTk.PhotoImage(file = "brocoli.jpeg")
    b10 = Button(fen1, image = p10, command = open_brocoli)
    b10.grid(row = 2, column = 5)

    #Bouton quitter de la fenêtre
    quit = Button(fen1 , text = "Quitter" , command = fen1.destroy)
    quit.grid(row = 3, column = 3)
    fen1.mainloop()


#Boulangerie
def rayon2():
    fen2 = Toplevel(fenPrin)
    fen2.geometry("950x420")
    fen2.title("Boulangerie")

    #Création la fenêtre de l'information 
    def open_baguette():
        baguette = Toplevel()
        baguette.geometry("900x100")
        baguette.title("Baguette")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(baguette, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('927462', 'Baguette Clasique', '21', '0€90'))
        tree.pack()
        baguette.mainloop()

    p1 = ImageTk.PhotoImage(file = "baguette.jpeg")
    b1 = Button(fen2, image = p1, command = open_baguette)
    b1.grid(row = 1, column = 1)

    #Création la fenêtre de l'information 
    def open_burger():
        burger = Toplevel()
        burger.geometry("900x100")
        burger.title("Burger")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(burger, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('173620', 'Bun AMÉRICAIN', '28', '0€19'))
        tree.pack()
        burger.mainloop()

    p2 = ImageTk.PhotoImage(file = "burger.jpeg")
    b2 = Button(fen2, image = p2, command = open_burger)
    b2.grid(row = 1, column = 2)

    #Création la fenêtre de l'information 
    def open_graincourge():
        graincourge = Toplevel()
        graincourge.geometry("900x100")
        graincourge.title("Pain Grain Courge")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(graincourge, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('037625', 'Pain Courge Tournesol', '9', '2€60'))
        tree.pack()
        graincourge.mainloop()

    p3 = ImageTk.PhotoImage(file = "graincourge.jpeg")
    b3 = Button(fen2, image = p3, command = open_graincourge)
    b3.grid(row = 1, column = 3)

    #Création la fenêtre de l'information 
    def open_chaussonpomme():
        chaussonpomme = Toplevel()
        chaussonpomme.geometry("900x100")
        chaussonpomme.title("Chaussons aux pommes")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(chaussonpomme, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('826453', 'Chaussons aux pommes', '8', '1€80'))
        tree.pack()
        chaussonpomme.mainloop()

    p4 = ImageTk.PhotoImage(file = "chaussonpomme.jpeg")
    b4 = Button(fen2, image = p4, command = open_chaussonpomme)
    b4.grid(row = 1, column = 4)

    #Création la fenêtre de l'information 
    def open_nordique():
        nordique = Toplevel()
        nordique.geometry("900x100")
        nordique.title("Pain Nordique")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(nordique, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('027462', 'Pain Nordique', '5', '2€40'))
        tree.pack()
        nordique.mainloop()

    p5 = ImageTk.PhotoImage(file = "nordique.jpeg")
    b5 = Button(fen2, image = p5, command = open_nordique)
    b5.grid(row = 1, column = 5)

    #Création la fenêtre de l'information 
    def open_croissant():
        croissant = Toplevel()
        croissant.geometry("900x100")
        croissant.title("Croissant")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(croissant, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('274620', '', '30', '0€90'))
        tree.pack()
        croissant.mainloop()

    p6 = ImageTk.PhotoImage(file = "croissant.jpeg")
    b6 = Button(fen2, image = p6, command = open_croissant)
    b6.grid(row = 2, column = 1)

    #Création la fenêtre de l'information 
    def open_chocolat():
        chocolat = Toplevel()
        chocolat.geometry("900x100")
        chocolat.title("Pain au chocolat")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(chocolat, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('827462', 'Pain au chocolat', '25', '1€'))
        tree.pack()
        chocolat.mainloop()

    p7 = ImageTk.PhotoImage(file = "chocolat.jpeg")
    b7 = Button(fen2, image = p7, command = open_chocolat)
    b7.grid(row = 2, column = 2)

    #Création la fenêtre de l'information 
    def open_mie():
        mie = Toplevel()
        mie.geometry("900x100")
        mie.title("Pain de mie")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(mie, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('163849', 'Pain de mie', '7', '1€70'))
        tree.pack()
        mie.mainloop()

    p8 = ImageTk.PhotoImage(file = "mie.jpeg")
    b8 = Button(fen2, image = p8, command = open_mie)
    b8.grid(row = 2, column = 3)

    #Création la fenêtre de l'information 
    def open_campagne():
        campagne = Toplevel()
        campagne.geometry("900x100")
        campagne.title("Pain de campagne")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(campagne, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('026451', 'Pain de campagne', '16', '2€35'))
        tree.pack()
        campagne.mainloop()

    p9 = ImageTk.PhotoImage(file = "campagne.jpeg")
    b9 = Button(fen2, image = p9, command = open_campagne)
    b9.grid(row = 2, column = 4)

    #Création la fenêtre de l'information 
    def open_croquant():
        croquant = Toplevel()
        croquant.geometry("900x100")
        croquant.title("Croquant aux amandes")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(croquant, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('472658', 'Croquant aux amandes', '10', '3€'))
        tree.pack()
        croquant.mainloop()

    p10 = ImageTk.PhotoImage(file = "croquantamande.jpeg")
    b10 = Button(fen2, image = p10, command = open_croquant)
    b10.grid(row = 2, column = 5)

    #Bouton quitter de la fenêtre
    quit = Button(fen2 , text = "Quitter" , command = fen2.destroy)
    quit.grid(row = 3, column = 3)
    fen2.mainloop()


#Boucherie et poissonerie
def rayon3():
    fen3 = Toplevel(fenPrin)
    fen3.geometry("950x420")
    fen3.title("Boucherie et Poissonnerie")

   #Création la fenêtre de l'information 
    def open_boeuf():
        boeuf = Toplevel()
        boeuf.geometry("900x100")
        boeuf.title("Boeuf")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(boeuf, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('938465', 'Boeuf', '30kg', '63€20/kg'))
        tree.pack()
        boeuf.mainloop()

    p1 = ImageTk.PhotoImage(file = "boeuf.jpeg")
    b1 = Button(fen3, image = p1, command = open_boeuf)
    b1.grid(row = 1, column = 1)

    #Création la fenêtre de l'information 
    def open_caille():
        caille = Toplevel()
        caille.geometry("900x100")
        caille.title("Caille")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(caille, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('027564', 'Caille', '30kg', '15€90/kg'))
        tree.pack()
        caille.mainloop()

    p2 = ImageTk.PhotoImage(file = "caille.jpeg")
    b2 = Button(fen3, image = p2, command = open_caille)
    b2.grid(row = 1, column = 2)

    #Création la fenêtre de l'information 
    def open_escalope():
        escalope = Toplevel()
        escalope.geometry("900x100")
        escalope.title("Escalope de dinde")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(escalope, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('193840', 'Escalope de dinde', '30kg', '19€52/kg'))
        tree.pack()
        escalope.mainloop()

    p3 = ImageTk.PhotoImage(file = "escalope.jpeg")
    b3 = Button(fen3, image = p3, command = open_escalope)
    b3.grid(row = 1, column = 3)

    #Création la fenêtre de l'information 
    def open_canard():
        canard = Toplevel()
        canard.geometry("900x100")
        canard.title("Magret de carnard")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(canard, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('036153', 'Magret de canard', '30kg', '26€90/kg'))
        tree.pack()
        canard.mainloop()

    p4 = ImageTk.PhotoImage(file = "canard.jpeg")
    b4 = Button(fen3, image = p4, command = open_canard)
    b4.grid(row = 1, column = 4)

    #Création la fenêtre de l'information 
    def open_porc():
        porc = Toplevel()
        porc.geometry("900x100")
        porc.title("Porc")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(porc, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('462547', 'Côtelette de porc', '30kg', '11€85/kg'))
        tree.pack()
        porc.mainloop()

    p5 = ImageTk.PhotoImage(file = "coteporc.jpeg")
    b5 = Button(fen3, image = p5, command = open_porc)
    b5.grid(row = 1, column = 5)

    #Création la fenêtre de l'information 
    def open_crevette():
        crevette = Toplevel()
        crevette.geometry("900x100")
        crevette.title("Crevette")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(crevette, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('645285', 'Crevette de Madagascar', '30kg', '13€98/kg'))
        tree.pack()
        crevette.mainloop()

    p6 = ImageTk.PhotoImage(file = "crevette.png")
    b6 = Button(fen3, image = p6, command = open_crevette)
    b6.grid(row = 2, column = 1)

    #Création la fenêtre de l'information 
    def open_dorade():
        dorade = Toplevel()
        dorade.geometry("900x100")
        dorade.title("Dorade")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(dorade, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('364920', 'Dorade Royale grattée/vidée', '30kg', '13€90/kg'))
        tree.pack()
        dorade.mainloop()

    p7 = ImageTk.PhotoImage(file = "dorade.jpeg")
    b7 = Button(fen3, image = p7, comman = open_dorade)
    b7.grid(row = 2, column = 2)

    #Création la fenêtre de l'information 
    def open_encornet():
        encornet = Toplevel()
        encornet.geometry("900x100")
        encornet.title("Encornet")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(encornet, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('016483', 'Encornet', '30kg', '22€00/kg'))
        tree.pack()
        encornet.mainloop()

    p8 = ImageTk.PhotoImage(file = "encornet.jpeg")
    b8 = Button(fen3, image = p8, command = open_encornet)
    b8.grid(row = 2, column = 3)

    #Création la fenêtre de l'information 
    def open_moule():
        moule = Toplevel()
        moule.geometry("900x100")
        moule.title("Moule")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(moule, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('285020', 'Moule de Bouchot', '30kg', '6€09/kg'))
        tree.pack()
        moule.mainloop()

    p9 = ImageTk.PhotoImage(file = "moule.jpeg")
    b9 = Button(fen3, image = p9, command = open_moule)
    b9.grid(row = 2, column = 4)

    #Création la fenêtre de l'information 
    def open_thon():
        thon = Toplevel()
        thon.geometry("900x100")
        thon.title("Thon")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(thon, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('635290', 'Thon rouge', '30kg', '15€50/pièce'))
        tree.pack()
        thon.mainloop()

    p10 = ImageTk.PhotoImage(file = "thon.jpeg")
    b10 = Button(fen3, image = p10, command = open_thon)
    b10.grid(row = 2, column = 5)

    #Bouton quitter de la fenêtre
    quit = Button(fen3 , text = "Quitter" , command = fen3.destroy)
    quit.grid(row = 3, column = 3)
    fen3.mainloop()


#Produit d'entretien
def rayon4():
    fen4 = Toplevel(fenPrin)
    fen4.geometry("950x420")
    fen4.title("Produit d'entretien")

    #Création la fenêtre de l'information 
    def open_cif():
        cif = Toplevel()
        cif.geometry("900x100")
        cif.title("Cif nettoyant")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(cif, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('917462', 'Cif Crème Multi Surfaces', '65', '2€35'))
        tree.pack()
        cif.mainloop()

    p1 = ImageTk.PhotoImage(file = "cif.jpeg")
    b1 = Button(fen4, image = p1, command = open_cif)
    b1.grid(row = 1, column = 1)

    #Création la fenêtre de l'information 
    def open_vaisselle():
        vaisselle = Toplevel()
        vaisselle.geometry("900x100")
        vaisselle.title("Liquide vaisselle")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(vaisselle, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('016441', 'Liquide vaisselle parfum Cerisier', '42', '1€53'))
        tree.pack()
        vaisselle.mainloop()

    p2 = ImageTk.PhotoImage(file = "vaisselle.jpeg")
    b2 = Button(fen4, image = p2, command = open_vaisselle)
    b2.grid(row = 1, column = 2)

    #Création la fenêtre de l'information 
    def open_combinebrosse():
        brosse = Toplevel()
        brosse.geometry("900x100")
        brosse.title("Kit brosse WC + socle")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(brosse, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('163518', 'Combiné brosse WC et socle blanc', '30', '2€62'))
        tree.pack()
        brosse.mainloop()

    p3 = ImageTk.PhotoImage(file = "combinebrosse.jpeg")
    b3 = Button(fen4, image = p3, command = open_combinebrosse)
    b3.grid(row = 1, column = 3)

    #Création la fenêtre de l'information 
    def open_bakingsoda():
        soda = Toplevel()
        soda.geometry("900x100")
        soda.title("Baking Soda")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(soda, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('017347', 'BIOVIE Bicarbonate de soude', '22', '3€26'))
        tree.pack()
        soda.mainloop()

    p4 = ImageTk.PhotoImage(file = "bakingsoda.jpeg")
    b4 = Button(fen4, image = p4, comman = open_bakingsoda)
    b4.grid(row = 1, column = 4)

    #Création la fenêtre de l'information 
    def open_sol():
        sol = Toplevel()
        sol.geometry("900x100")
        sol.title("Nettoyant parfumant et désinfectant")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(sol, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('294756', 'Désinfectant sols et surfaces', '17', '16€32'))
        tree.pack()
        sol.mainloop()

    p5 = ImageTk.PhotoImage(file = "sols.jpeg")
    b5 = Button(fen4, image = p5, comman = open_sol)
    b5.grid(row = 1, column = 5)

    #Création la fenêtre de l'information 
    def open_lingette():
        lingette = Toplevel()
        lingette.geometry("900x100")
        lingette.title("Lingette nettoyant")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(lingette, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('926452', 'Lingettes nettoyantes', '40', '1€56'))
        tree.pack()
        lingette.mainloop()

    p6 = ImageTk.PhotoImage(file = "lingette.jpeg")
    b6 = Button(fen4, image = p6, command = open_lingette)
    b6.grid(row = 2, column = 1)

    #Création la fenêtre de l'information 
    def open_nettoyant():
        nettoyant = Toplevel()
        nettoyant.geometry("900x100")
        nettoyant.title("Nettoyant dégraissant vitres")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(nettoyant, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('235472', 'Nettoyant vitres', '16', '14€65'))
        tree.pack()
        nettoyant.mainloop()

    p7 = ImageTk.PhotoImage(file = "nettoyant.jpeg")
    b7 = Button(fen4, image = p7, command = open_nettoyant)
    b7.grid(row = 2, column = 2)

    #Création la fenêtre de l'information 
    def open_javel():
        javel = Toplevel()
        javel.geometry("900x100")
        javel.title("Gel toilette Javel")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(javel, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('635104', 'Gel Javel WC 3in1', '16', '1€30'))
        tree.pack()
        javel.mainloop()

    p8 = ImageTk.PhotoImage(file = "javel.jpeg")
    b8 = Button(fen4, image = p8, command = open_javel)
    b8.grid(row = 2, column = 3)

    #Création la fenêtre de l'information 
    def open_lavette():
        lavette = Toplevel()
        lavette.geometry("900x100")
        lavette.title("Nettoyant dégraissant vitres")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(lavette, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('502940', 'Lavettes tissées', '50', '15€80'))
        tree.pack()
        lavette.mainloop()

    p9 = ImageTk.PhotoImage(file = "lavette.jpeg")
    b9 = Button(fen4, image = p9, command = open_lavette)
    b9.grid(row = 2, column = 4)

    #Création la fenêtre de l'information 
    def open_gant():
        gant = Toplevel()
        gant.geometry("900x100")
        gant.title("Gant nettoyant")

        #Ajouter le Treeview widget
        tree = ttk.Treeview(gant, columns = ("c1", "c2", "c3", "c4"), show = 'headings')
        tree.column("#1", anchor = CENTER)
        tree.heading("#1", text = "ID")
        tree.column("#2", anchor = CENTER)
        tree.heading("#2", text = "NOM")
        tree.column("#3", anchor = CENTER)
        tree.heading("#3", text = "QUANTITÉ EN STOCK")
        tree.column("#4", anchor = CENTER)
        tree.heading("#4", text = "PRIX")

        #Insérez les données dans le widget Treeview
        tree.insert('', 'end', text = "1", values = ('539502', 'Gants de nettoyage', '38', '3€61'))
        tree.pack()
        gant.mainloop()

    p10 = ImageTk.PhotoImage(file = "gant.jpeg")
    b10 = Button(fen4, image = p10, command = open_gant)
    b10.grid(row = 2, column = 5)

    #Bouton quitter de la fenêtre
    quit = Button(fen4 , text = "Quitter" , command = fen4.destroy)
    quit.grid(row = 3, column = 3)   
    fen4.mainloop()

#Création des boutons de 4 rayons
but1 = Button(fenPrin, image = new_img1, command = rayon1)
but1.place(x = 100, y = 100)

but2 = Button(fenPrin, image = new_img2, command = rayon2)
but2.place(x = 100, y = 400)

but3 = Button(fenPrin, image = new_img3, command = rayon3)
but3.place(x = 600, y = 100)

but4 = Button(fenPrin, image = new_img4, command = rayon4)
but4.place(x = 600, y = 400)

#Bouton quitter de la fenêtre principale
quitBut = Button(fenPrin, text = "Quitter", command = quit)
quitBut.pack(side = "bottom")

fenPrin.mainloop()
