from tkinter import *
from tkinter import messagebox
from openpyxl import *
import pandas as pd


interface_pour_ajouter_un_manager = Tk()
interface_pour_ajouter_un_manager.geometry("527x520")
interface_pour_ajouter_un_manager.title("GesMag")
interface_pour_ajouter_un_manager.configure(bg = '#FFFFFF')


label_ajouter_manager = Label(interface_pour_ajouter_un_manager, text = "Ajoutez un nouveau manager", font = ("Arial", 15, 'bold'), fg = 'white', bg = '#375D81', width = 30, height = 1, bd = 3, relief = 'groove')
label_ajouter_manager.grid(row = 0, columnspan = 2, pady = 10)


identifiant_et_login_manager = StringVar()
label_pour_indentifiant_et_login_manager = Label(interface_pour_ajouter_un_manager, text = "Indentifiant :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_indentifiant_et_login_manager.grid(row = 1, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_identifiant_et_login_manager = Entry(interface_pour_ajouter_un_manager, textvariable = identifiant_et_login_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_identifiant_et_login_manager.grid(row = 1, column = 1, sticky = E, padx = 35, pady = 10)
zone_de_saisi_pour_identifiant_et_login_manager.focus()


nom_manager = StringVar()
label_pour_nom_manager = Label(interface_pour_ajouter_un_manager, text = "Nom :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_nom_manager.grid(row = 2, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_nom_manager = Entry(interface_pour_ajouter_un_manager, textvariable = nom_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_nom_manager.grid(row = 2, column = 1, sticky = E, padx = 35, pady = 10)


prenom_manager = StringVar()
label_pour_prenom_manager = Label(interface_pour_ajouter_un_manager, text = "Prenom :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_prenom_manager.grid(row = 3, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_prenom_manager = Entry(interface_pour_ajouter_un_manager, textvariable = prenom_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_prenom_manager.grid(row = 3, column = 1, sticky = E, padx = 35, pady = 10)


frame = Frame(interface_pour_ajouter_un_manager, width = 400, height = 2, bg = 'white')
frame.grid(row = 4, columnspan = 2, sticky = E, padx = 35, pady = 10)


date_de_naissance_du_manager = StringVar()
date_de_naissance_du_manager2 = StringVar()
date_de_naissance_du_manager3 = StringVar()
label_pour_date_de_naissance = Label(interface_pour_ajouter_un_manager, text = "Date de naissance :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_date_de_naissance.grid(row = 4, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_date_de_naissance_manager = Entry(frame, textvariable = date_de_naissance_du_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 6)
zone_de_saisi_pour_date_de_naissance_manager.grid(row = 0, column = 0, sticky = W, padx = 4)
label_pour_slash = Label(frame, text = "/", width = 1, font = ('bold'), bg = 'white')
label_pour_slash.grid(row = 0, column = 1, padx = 1)
zone_de_saisi_pour_date_de_naissance_manager2 = Entry(frame, textvariable = date_de_naissance_du_manager2, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 6)
zone_de_saisi_pour_date_de_naissance_manager2.grid(row = 0, column = 2, sticky = E, padx = 4)
label_pour_slash2 = Label(frame, text = "/",  width = 1, font = ('bold'), bg = 'white')
label_pour_slash2.grid(row = 0, column = 3, padx = 1)
zone_de_saisi_pour_date_de_naissance_manager3 = Entry(frame, textvariable = date_de_naissance_du_manager3, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 7)
zone_de_saisi_pour_date_de_naissance_manager3.grid(row = 0, column = 4, sticky = E, padx = 4)


adresse_manager = StringVar()
label_pour_adresse = Label(interface_pour_ajouter_un_manager, text = "Adresse :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_adresse.grid(row = 5, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_adresse_manager = Entry(interface_pour_ajouter_un_manager, textvariable = adresse_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_adresse_manager.grid(row = 5, column = 1, sticky = E, padx = 35, pady = 10)


code_postal_manager = StringVar()
label_pour_code_postal_manager = Label(interface_pour_ajouter_un_manager, text = "Code postal :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_code_postal_manager.grid(row = 6, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_code_postal_manager = Entry(interface_pour_ajouter_un_manager, textvariable = code_postal_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_code_postal_manager.grid(row = 6, column = 1, sticky = E, padx = 35, pady = 10)


label_pour_login_manager = Label(interface_pour_ajouter_un_manager, text = "Login :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_login_manager.grid(row = 7, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_login_manager = Entry(interface_pour_ajouter_un_manager, textvariable = identifiant_et_login_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_login_manager.grid(row = 7, column = 1, sticky = E, padx = 35, pady = 10)


mot_de_passe_manager = StringVar()
label_pour_mot_de_passe_manager = Label(interface_pour_ajouter_un_manager, text = "Mot de passe :", font = ("Arial", 12, 'bold'), bg = 'white')
label_pour_mot_de_passe_manager.grid(row = 8, column = 0, sticky = W, padx = 35, pady = 10)
zone_de_saisi_pour_mot_de_passe_manager = Entry(interface_pour_ajouter_un_manager, textvariable = mot_de_passe_manager, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_pour_mot_de_passe_manager.grid(row = 8, column = 1, sticky = E, padx = 35, pady = 10)


wb = load_workbook('base_de_données_caissiers_et_managers.xlsx')
sheet = wb.active
df = pd.read_excel('base_de_données_caissiers_et_managers.xlsx')

def ajouter():
    current_row = sheet.max_row
    current_column = sheet.max_column

    sheet.cell(row = current_row + 1, column = 1).value = zone_de_saisi_pour_identifiant_et_login_manager.get()
    sheet.cell(row = current_row + 1, column = 2).value = zone_de_saisi_pour_nom_manager.get()
    sheet.cell(row = current_row + 1, column = 3).value = zone_de_saisi_pour_prenom_manager.get()
    sheet.cell(row = current_row + 1, column = 4).value = zone_de_saisi_pour_date_de_naissance_manager.get() + "/" + zone_de_saisi_pour_date_de_naissance_manager2.get() + "/" + zone_de_saisi_pour_date_de_naissance_manager3.get()
    sheet.cell(row = current_row + 1, column = 5).value = zone_de_saisi_pour_adresse_manager.get()
    sheet.cell(row = current_row + 1, column = 6).value = zone_de_saisi_pour_code_postal_manager.get()
    sheet.cell(row = current_row + 1, column = 7).value = zone_de_saisi_pour_login_manager.get()
    sheet.cell(row = current_row + 1, column = 8).value = zone_de_saisi_pour_mot_de_passe_manager.get()

    wb.save('base_de_données_caissiers_et_managers.xlsx')

    vider()
 

def enregistrement_verification():
    caracteres_speciaux = [".", "+", "-", "*", "/", "!", "§", ":", ";", "?", ",", "&", "~", "#", '"', "'", "{", "(", "[", "|", "`", "_", "^", "@", ")", "°", "]", "=", "}", "$", "£", "¨", "µ", "%", "<", ">"] 


    if len(zone_de_saisi_pour_identifiant_et_login_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un identifiant")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_identifiant_et_login_manager.get()):
        messagebox.showerror(message = "Pas de caractères speciaux")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_identifiant_et_login_manager.get()):
        messagebox.showerror(message = "Pas de minuscule")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    elif not zone_de_saisi_pour_identifiant_et_login_manager.get().startswith('M'):
        messagebox.showerror(message = "Identifiant devrait commencé par un 'M'")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    elif not any(i.isdigit() for i in zone_de_saisi_pour_identifiant_et_login_manager.get()):
        messagebox.showerror(message = "Au moins un chiffre")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    elif not (len(zone_de_saisi_pour_identifiant_et_login_manager.get()) > 5):
        messagebox.showerror(message = "5 caractères maximum")
        zone_de_saisi_pour_identifiant_et_login_manager.focus()
    
    elif len(zone_de_saisi_pour_nom_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un nom")
        zone_de_saisi_pour_nom_manager.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_nom_manager.get()):
        messagebox.showerror(message = "Pas de caractères speciaux")
        zone_de_saisi_pour_nom_manager.focus()
    elif any(i.isdigit() for i in zone_de_saisi_pour_nom_manager.get()):
        messagebox.showerror(message = "Pas de chiffres")
        zone_de_saisi_pour_nom_manager.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_nom_manager.get()):
        messagebox.showerror(message = "Nom doit etre ecrit en majuscle")
        zone_de_saisi_pour_nom_manager.focus()


    elif len(zone_de_saisi_pour_prenom_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un prenom")
        zone_de_saisi_pour_prenom_manager.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_prenom_manager.get()):
        messagebox.showerror(message = "Pas de caractères speciaux")
        zone_de_saisi_pour_prenom_manager.focus()
    elif any(i.isdigit() for i in zone_de_saisi_pour_prenom_manager.get()):
        messagebox.showerror(message = "Pas de chiffres")
        zone_de_saisi_pour_prenom_manager.focus()
    elif not any(i.islower() for i in zone_de_saisi_pour_prenom_manager.get()):
        messagebox.showerror(message = "Prenom doit contenir des minuscule")
        zone_de_saisi_pour_prenom_manager.focus()
    elif not any(i.isupper() for i in zone_de_saisi_pour_prenom_manager.get()):
        messagebox.showerror(message = "Prenom doit commencé par une majuscle")
        zone_de_saisi_pour_prenom_manager.focus()


    elif len(zone_de_saisi_pour_date_de_naissance_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un date de naissance")
        zone_de_saisi_pour_date_de_naissance_manager.focus()
    elif any(i.isupper() for i in zone_de_saisi_pour_date_de_naissance_manager.get()):
        messagebox.showerror(message = "Pas de majuscle")
        zone_de_saisi_pour_date_de_naissance_manager.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_date_de_naissance_manager.get()):
        messagebox.showerror(message = "Pas de minuscule")
        zone_de_saisi_pour_date_de_naissance_manager.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_date_de_naissance_manager.get()):
        messagebox.showerror(message = "Pas de caractères speciaux")
        zone_de_saisi_pour_date_de_naissance_manager.focus()
    elif len(zone_de_saisi_pour_date_de_naissance_manager.get()) != 2:
        messagebox.showerror(message = "1 nombre compris entre 1 et 31")
        zone_de_saisi_pour_date_de_naissance_manager.focus()


    elif len(zone_de_saisi_pour_date_de_naissance_manager2.get()) == 0:
        messagebox.showwarning(message = "Saisissez un date de naissance")
        zone_de_saisi_pour_date_de_naissance_manager2.focus()
    elif any(i.isupper() for i in zone_de_saisi_pour_date_de_naissance_manager2.get()):
        messagebox.showerror(message = "Pas de majuscle")
        zone_de_saisi_pour_date_de_naissance_manager2.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_date_de_naissance_manager2.get()):
        messagebox.showerror(message = "Pas de minuscule")
        zone_de_saisi_pour_date_de_naissance_manager2.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_date_de_naissance_manager2.get()):
        messagebox.showerror(message = "Pas de caracteres speciaux")
        zone_de_saisi_pour_date_de_naissance_manager2.focus()
    elif len(zone_de_saisi_pour_date_de_naissance_manager2.get()) != 2:
        messagebox.showerror(message = "1 nombre compris entre 1 et 12")
        zone_de_saisi_pour_date_de_naissance_manager2.focus()


    elif len(zone_de_saisi_pour_date_de_naissance_manager3.get()) == 0:
        messagebox.showwarning(message = "Saisissez un date de naissance")
        zone_de_saisi_pour_date_de_naissance_manager3.focus()
    elif any(i.isupper() for i in zone_de_saisi_pour_date_de_naissance_manager3.get()):
        messagebox.showerror(message = "Pas de majuscle")
        zone_de_saisi_pour_date_de_naissance_manager3.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_date_de_naissance_manager3.get()):
        messagebox.showerror(message = "Pas de minuscule")
        zone_de_saisi_pour_date_de_naissance_manager3.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_date_de_naissance_manager3.get()):
        messagebox.showerror(message = "Pas de caracteres speciaux")
        zone_de_saisi_pour_date_de_naissance_manager3.focus()
    elif len(zone_de_saisi_pour_date_de_naissance_manager3.get()) != 4:
        messagebox.showerror(message = "1 nombre a 4 chiffres")
        zone_de_saisi_pour_date_de_naissance_manager3.focus()

    elif len(zone_de_saisi_pour_adresse_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez une adresse")
        zone_de_saisi_pour_adresse_manager.focus()

    elif len(zone_de_saisi_pour_code_postal_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un code postal")
        zone_de_saisi_pour_code_postal_manager.focus()
    elif any(i.isupper() for i in zone_de_saisi_pour_code_postal_manager.get()):
        messagebox.showerror(message = "Pas de majuscle")
        zone_de_saisi_pour_code_postal_manager.focus()
    elif any(i.islower() for i in zone_de_saisi_pour_code_postal_manager.get()):
        messagebox.showerror(message = "Pas de minuscule")
        zone_de_saisi_pour_code_postal_manager.focus()
    elif any(i in caracteres_speciaux for i in zone_de_saisi_pour_code_postal_manager.get()):
        messagebox.showerror(message = "Pas de caracteres speciaux")
        zone_de_saisi_pour_code_postal_manager.focus()
    elif len(zone_de_saisi_pour_code_postal_manager.get()) != 5:
        messagebox.showerror(message = "1 nombre a 5 chiffres")
        zone_de_saisi_pour_code_postal_manager.focus()


    elif len(zone_de_saisi_pour_mot_de_passe_manager.get()) == 0:
        messagebox.showwarning(message = "Saisissez un mot de passe")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    elif not any(i in caracteres_speciaux for i in zone_de_saisi_pour_mot_de_passe_manager.get()):
        messagebox.showerror(message =  "Au moins un caractere special")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    elif not any(i.islower() for i in zone_de_saisi_pour_mot_de_passe_manager.get()):
        messagebox.showerror(message = "Au moins une minuscule ")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    elif not any(i.isupper() for i in zone_de_saisi_pour_mot_de_passe_manager.get()):
        messagebox.showerror(message = "Au moins une majuscule")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    elif not any(i.isdigit() for i in zone_de_saisi_pour_mot_de_passe_manager.get()):
        messagebox.showerror(message = "Au moins un chiffre")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    elif len(zone_de_saisi_pour_mot_de_passe_manager.get()) < 8:
        messagebox.showerror(message = "Au moins 8 caracteres")
        zone_de_saisi_pour_mot_de_passe_manager.focus()
    

    else:
        verification_dans_identifiant = df["Identifiant"].values
        verification_dans_mot_de_passe = df["Mot de passe"].values
        if zone_de_saisi_pour_identifiant_et_login_manager.get() in verification_dans_identifiant:
            messagebox.showerror(message = "Identifiant existe deja, saisissez un autre identifiant")
            zone_de_saisi_pour_identifiant_et_login_manager.focus() 
        elif zone_de_saisi_pour_mot_de_passe_manager.get() in verification_dans_mot_de_passe:
            messagebox.showerror(message = "Mot de passe existe deja, saisissez un autre mot de passe")
            zone_de_saisi_pour_mot_de_passe_manager.focus() 
        else:
            #ajouter()
            messagebox.showinfo(message = "Enregistré avec succes")
            zone_de_saisi_pour_identifiant_et_login_manager.focus()


def vider():
    zone_de_saisi_pour_identifiant_et_login_manager.delete(0, END)
    zone_de_saisi_pour_nom_manager.delete(0, END)
    zone_de_saisi_pour_prenom_manager.delete(0, END)
    zone_de_saisi_pour_date_de_naissance_manager.delete(0, END)
    zone_de_saisi_pour_date_de_naissance_manager2.delete(0, END)
    zone_de_saisi_pour_date_de_naissance_manager3.delete(0, END)
    zone_de_saisi_pour_adresse_manager.delete(0, END)
    zone_de_saisi_pour_code_postal_manager.delete(0, END)
    zone_de_saisi_pour_login_manager.delete(0, END)
    zone_de_saisi_pour_mot_de_passe_manager.delete(0, END)


def quitter():
    interface_pour_ajouter_un_manager.destroy()


bouton_pour_enregistrer = Button(interface_pour_ajouter_un_manager, text = "Enregistrer", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#6FC771', activebackground = '#6FC771', activeforeground = 'white', cursor = 'hand2', command = enregistrement_verification)
bouton_pour_enregistrer.grid(row = 9, column = 1, sticky = E, padx = 35, pady = 30)


bouton_pour_vider = Button(interface_pour_ajouter_un_manager, text = "Vider", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#F4D03F', activebackground = '#F4D03F', activeforeground = 'white', cursor = 'hand2', command = vider)
bouton_pour_vider.grid(row = 9, columnspan = 2)


bouton_pour_quitter = Button(interface_pour_ajouter_un_manager, text = "Quitter", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#F32665', activebackground = '#F32665', activeforeground = 'white', cursor = 'hand2', command = quitter)
bouton_pour_quitter.grid(row = 9, column = 0, sticky = W, padx = 35, pady = 30)


interface_pour_ajouter_un_manager.mainloop()