from tkinter import *
import pandas as pd
from tkinter import ttk
from tkinter import messagebox


interface_pour_afficher_les_caissiers_et_les_managers = Tk()
interface_pour_afficher_les_caissiers_et_les_managers.geometry("1625x500")
interface_pour_afficher_les_caissiers_et_les_managers.title(string = "GesMag")
interface_pour_afficher_les_caissiers_et_les_managers.configure(bg = 'white')


label_afficher_caissier = Label(interface_pour_afficher_les_caissiers_et_les_managers, text = "Affichage des caissiers", font = ("Arial", 15, 'bold'), fg = 'white', bg = '#375D81', width = 25, height = 1, bd = 3, relief = 'groove')
label_afficher_caissier.grid(row = 0, columnspan = 2, pady = 10)


frame = Frame(interface_pour_afficher_les_caissiers_et_les_managers, width = 865, height = 120, bg = 'white')
frame.grid(pady = 10)
frame.grid_propagate(0)


label_trouver_identifiant_caissier = Label(frame, text = "Identifiant :", font = ("Arial", 12, 'bold'), bg = 'white')
label_trouver_identifiant_caissier.grid(row = 0, column = 0, padx = 35, pady = 10)
zone_de_saisi_trouver_identifiant_caissier = Entry(frame, font = ("Arial", 12), bg = '#e3e3e3', bd = 3, width = 27)
zone_de_saisi_trouver_identifiant_caissier.grid(row = 0, column = 1, padx = 35, pady = 10)


tableau = ttk.Treeview(interface_pour_afficher_les_caissiers_et_les_managers)
tableau.grid()


df = pd.read_excel('base_de_données_caissiers_et_managers.xlsx')


tableau["column"] = list(df.columns)
tableau["show"] = "headings"
for colonne in tableau["column"]:
    tableau.heading(colonne, text = colonne)


def afficher():
    une_seule_fois()
    trouver = df["Identifiant"].values
    if zone_de_saisi_trouver_identifiant_caissier.get() in trouver:
        data = pd.read_excel('base_de_données_caissiers_et_managers.xlsx', index_col = "Identifiant")
        searched = data.loc[zone_de_saisi_trouver_identifiant_caissier.get()]
        tableau.insert("","end", values = (zone_de_saisi_trouver_identifiant_caissier.get() + " " + str(searched.values.tolist())[1:-1]))
    else:
        messagebox.showerror(message = "Identifiant non trouvé")


def afficher_tous():
    une_seule_fois()
    df_ligne = df.to_numpy().tolist()
    for ligne in df_ligne:
        tableau.insert("", "end", values = ligne)
        


def une_seule_fois():
    tableau.delete(*tableau.get_children())


def vider():
    zone_de_saisi_trouver_identifiant_caissier.delete(0, END)


def quitter():
    interface_pour_afficher_les_caissiers_et_les_managers.destroy()


bouton_pour_afficher = Button(frame, text = "Afficher", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#6FC771', activebackground = '#6FC771', activeforeground = 'white', cursor = 'hand2', command = afficher)
bouton_pour_afficher.grid(row = 0, column = 3, padx = 35, pady = 10, sticky = E)


bouton_pour_afficher_tous = Button(frame, text = "Afficher tous", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#6FC771', activebackground = '#6FC771', activeforeground = 'white', cursor = 'hand2', command = afficher_tous)
bouton_pour_afficher_tous.grid(row = 2, column = 3, padx = 35, pady = 10, sticky = E)


bouton_pour_quitter = Button(frame, text = "Vider", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#F4D03F', activebackground = '#F4D03F', activeforeground = 'white', cursor = 'hand2', command = vider)
bouton_pour_quitter.grid(row = 0, column = 4, padx = 35, pady = 10, sticky = E)


bouton_pour_vider = Button(interface_pour_afficher_les_caissiers_et_les_managers, text = "Quitter", font = ('Arial', 12, 'bold'), width = 10, bd = 3, bg = 'white', fg = '#F32665', activebackground = '#F32665', activeforeground = 'white', cursor = 'hand2', command = quitter)
bouton_pour_vider.grid(pady = 30)


interface_pour_afficher_les_caissiers_et_les_managers.mainloop()